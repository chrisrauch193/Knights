Knights Game Package

`pip install git+git://github.com/chrisrauch193/BBOXX_Interview.git#egg=BBOXX_Game`